# Example Repository 1

- **Owner:** [John Doe](https://github.com/john_doe) (john@example.com)
- **Description:** This is an example repository.
- **Language:** JavaScript
- **Forks:** 10
- **Stars:** 50
- **Open Issues:** 2
- **Created At:** 2024-01-01
- **Last Updated At:** 2024-03-27
- **GitHub Repository:** [example-repo-1](https://github.com/example/example-repo-1)
