import translation from './translation.json';

export default { translation } as const;
